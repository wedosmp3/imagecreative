{
	"file_path": "C:\\Users\\User\\AppData\\Local\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState\\games\\com.mojang\\development_behavior_packs\\Gravestones\\entities\\player.json",
	"file_type": "entity",
	"format_version": 1,
	"file_uuid": "3db16a8f_012b_4dc8_8448_6413ffed0719",
	"file_version": 39,
	"cache_content": {
		"children": [
			{
				"open": {
					"format_version": "1.13.0",
					"minecraft:entity": {
						"description": {
							"identifier": "minecraft:player",
							"is_spawnable": false,
							"is_summonable": false,
							"is_experimental": false
						},
						"component_groups": {
							"minecraft:add_bad_omen": {
								"minecraft:spell_effects": {
									"add_effects": [
										{
											"effect": "bad_omen",
											"duration": 6000,
											"display_on_screen_animation": true
										}
									]
								},
								"minecraft:timer": {
									"time": [
										0,
										0
									],
									"looping": false,
									"time_down_event": {
										"event": "minecraft:clear_add_bad_omen",
										"target": "self"
									}
								}
							},
							"minecraft:clear_bad_omen_spell_effect": {
								"minecraft:spell_effects": {}
							},
							"minecraft:raid_trigger": {
								"minecraft:raid_trigger": {
									"triggered_event": {
										"event": "minecraft:remove_raid_trigger",
										"target": "self"
									}
								},
								"minecraft:spell_effects": {
									"remove_effects": "bad_omen"
								}
							},
							"gvs:comp": {
								"minecraft:timer": {
									"time": 20,
									"time_down_event": {
										"event": "gvs:final"
									}
								}
							},
							"gvs:give": {
								"minecraft:spawn_entity": [
									{
										"num_to_spawn": 1,
										"spawn_item": "minecraft:compound"
									}
								]
							}
						},
						"components": {
							"minecraft:experience_reward": {
								"on_death": "Math.Min(query.player_level * 7, 100)"
							},
							"minecraft:type_family": {
								"family": [
									"player"
								]
							},
							"minecraft:is_hidden_when_invisible": {},
							"minecraft:loot": {
								"table": "loot_tables/empty.json"
							},
							"minecraft:collision_box": {
								"width": 0.6,
								"height": 1.8
							},
							"minecraft:can_climb": {},
							"minecraft:movement": {
								"value": 0.1
							},
							"minecraft:hurt_on_condition": {
								"damage_conditions": [
									{
										"filters": {
											"test": "in_lava",
											"subject": "self",
											"operator": "==",
											"value": true
										},
										"cause": "lava",
										"damage_per_tick": 4
									}
								]
							},
							"minecraft:attack": {
								"damage": 1
							},
							"minecraft:player.saturation": {
								"value": 20
							},
							"minecraft:player.exhaustion": {
								"value": 0,
								"max": 4
							},
							"minecraft:player.level": {
								"value": 0,
								"max": 24791
							},
							"minecraft:player.experience": {
								"value": 0,
								"max": 1
							},
							"minecraft:breathable": {
								"total_supply": 15,
								"suffocate_time": -1,
								"inhale_time": 3.75,
								"generates_bubbles": false
							},
							"minecraft:nameable": {
								"always_show": true,
								"allow_name_tag_renaming": false
							},
							"minecraft:physics": {},
							"minecraft:pushable": {
								"is_pushable": false,
								"is_pushable_by_piston": true
							},
							"minecraft:insomnia": {
								"days_until_insomnia": 3
							},
							"minecraft:rideable": {
								"seat_count": 2,
								"family_types": [
									"parrot_tame"
								],
								"pull_in_entities": true,
								"seats": [
									{
										"position": [
											0.4,
											-0.2,
											-0.1
										],
										"min_rider_count": 0,
										"max_rider_count": 0,
										"lock_rider_rotation": 0
									},
									{
										"position": [
											-0.4,
											-0.2,
											-0.1
										],
										"min_rider_count": 1,
										"max_rider_count": 2,
										"lock_rider_rotation": 0
									}
								]
							},
							"minecraft:scaffolding_climber": {},
							"minecraft:environment_sensor": {
								"triggers": {
									"filters": {
										"all_of": [
											{
												"test": "has_mob_effect",
												"subject": "self",
												"value": "bad_omen"
											},
											{
												"test": "is_in_village",
												"subject": "self",
												"value": true
											}
										]
									},
									"event": "minecraft:trigger_raid"
								}
							},
							"minecraft:damage_sensor": {
								"triggers": [
									{
										"cause": "contact"
									},
									{
										"cause": "all",
										"on_damage": {
											"filters": {
												"with_damage_fatal": true
											},
											"event": "gvs:spawn_grave"
										}
									}
								]
							}
						},
						"events": {
							"minecraft:gain_bad_omen": {
								"add": {
									"component_groups": [
										"minecraft:add_bad_omen"
									]
								}
							},
							"minecraft:clear_add_bad_omen": {
								"remove": {
									"component_groups": [
										"minecraft:add_bad_omen"
									]
								},
								"add": {
									"component_groups": [
										"minecraft:clear_bad_omen_spell_effect"
									]
								}
							},
							"minecraft:trigger_raid": {
								"add": {
									"component_groups": [
										"minecraft:raid_trigger"
									]
								}
							},
							"minecraft:remove_raid_trigger": {
								"remove": {
									"component_groups": [
										"minecraft:raid_trigger"
									]
								}
							},
							"gvs:spawn_grave": {
								"execute": {
									"commands": [
										"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
										"/give @s mcbp:grave_key"
									]
								}
							},
							"gvs:final": {
								"add": {
									"component_groups": [
										"gvs:give"
									]
								}
							},
							"gvs:test": {}
						}
					}
				},
				"data": "1.13.0",
				"key": "format_version"
			},
			{
				"open": {
					"format_version": "1.13.0",
					"minecraft:entity": {
						"description": {
							"identifier": "minecraft:player",
							"is_spawnable": false,
							"is_summonable": false,
							"is_experimental": false
						},
						"component_groups": {
							"minecraft:add_bad_omen": {
								"minecraft:spell_effects": {
									"add_effects": [
										{
											"effect": "bad_omen",
											"duration": 6000,
											"display_on_screen_animation": true
										}
									]
								},
								"minecraft:timer": {
									"time": [
										0,
										0
									],
									"looping": false,
									"time_down_event": {
										"event": "minecraft:clear_add_bad_omen",
										"target": "self"
									}
								}
							},
							"minecraft:clear_bad_omen_spell_effect": {
								"minecraft:spell_effects": {}
							},
							"minecraft:raid_trigger": {
								"minecraft:raid_trigger": {
									"triggered_event": {
										"event": "minecraft:remove_raid_trigger",
										"target": "self"
									}
								},
								"minecraft:spell_effects": {
									"remove_effects": "bad_omen"
								}
							},
							"gvs:comp": {
								"minecraft:timer": {
									"time": 20,
									"time_down_event": {
										"event": "gvs:final"
									}
								}
							},
							"gvs:give": {
								"minecraft:spawn_entity": [
									{
										"num_to_spawn": 1,
										"spawn_item": "minecraft:compound"
									}
								]
							}
						},
						"components": {
							"minecraft:experience_reward": {
								"on_death": "Math.Min(query.player_level * 7, 100)"
							},
							"minecraft:type_family": {
								"family": [
									"player"
								]
							},
							"minecraft:is_hidden_when_invisible": {},
							"minecraft:loot": {
								"table": "loot_tables/empty.json"
							},
							"minecraft:collision_box": {
								"width": 0.6,
								"height": 1.8
							},
							"minecraft:can_climb": {},
							"minecraft:movement": {
								"value": 0.1
							},
							"minecraft:hurt_on_condition": {
								"damage_conditions": [
									{
										"filters": {
											"test": "in_lava",
											"subject": "self",
											"operator": "==",
											"value": true
										},
										"cause": "lava",
										"damage_per_tick": 4
									}
								]
							},
							"minecraft:attack": {
								"damage": 1
							},
							"minecraft:player.saturation": {
								"value": 20
							},
							"minecraft:player.exhaustion": {
								"value": 0,
								"max": 4
							},
							"minecraft:player.level": {
								"value": 0,
								"max": 24791
							},
							"minecraft:player.experience": {
								"value": 0,
								"max": 1
							},
							"minecraft:breathable": {
								"total_supply": 15,
								"suffocate_time": -1,
								"inhale_time": 3.75,
								"generates_bubbles": false
							},
							"minecraft:nameable": {
								"always_show": true,
								"allow_name_tag_renaming": false
							},
							"minecraft:physics": {},
							"minecraft:pushable": {
								"is_pushable": false,
								"is_pushable_by_piston": true
							},
							"minecraft:insomnia": {
								"days_until_insomnia": 3
							},
							"minecraft:rideable": {
								"seat_count": 2,
								"family_types": [
									"parrot_tame"
								],
								"pull_in_entities": true,
								"seats": [
									{
										"position": [
											0.4,
											-0.2,
											-0.1
										],
										"min_rider_count": 0,
										"max_rider_count": 0,
										"lock_rider_rotation": 0
									},
									{
										"position": [
											-0.4,
											-0.2,
											-0.1
										],
										"min_rider_count": 1,
										"max_rider_count": 2,
										"lock_rider_rotation": 0
									}
								]
							},
							"minecraft:scaffolding_climber": {},
							"minecraft:environment_sensor": {
								"triggers": {
									"filters": {
										"all_of": [
											{
												"test": "has_mob_effect",
												"subject": "self",
												"value": "bad_omen"
											},
											{
												"test": "is_in_village",
												"subject": "self",
												"value": true
											}
										]
									},
									"event": "minecraft:trigger_raid"
								}
							},
							"minecraft:damage_sensor": {
								"triggers": [
									{
										"cause": "contact"
									},
									{
										"cause": "all",
										"on_damage": {
											"filters": {
												"with_damage_fatal": true
											},
											"event": "gvs:spawn_grave"
										}
									}
								]
							}
						},
						"events": {
							"minecraft:gain_bad_omen": {
								"add": {
									"component_groups": [
										"minecraft:add_bad_omen"
									]
								}
							},
							"minecraft:clear_add_bad_omen": {
								"remove": {
									"component_groups": [
										"minecraft:add_bad_omen"
									]
								},
								"add": {
									"component_groups": [
										"minecraft:clear_bad_omen_spell_effect"
									]
								}
							},
							"minecraft:trigger_raid": {
								"add": {
									"component_groups": [
										"minecraft:raid_trigger"
									]
								}
							},
							"minecraft:remove_raid_trigger": {
								"remove": {
									"component_groups": [
										"minecraft:raid_trigger"
									]
								}
							},
							"gvs:spawn_grave": {
								"execute": {
									"commands": [
										"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
										"/give @s mcbp:grave_key"
									]
								}
							},
							"gvs:final": {
								"add": {
									"component_groups": [
										"gvs:give"
									]
								}
							},
							"gvs:test": {}
						}
					}
				},
				"key": "minecraft:entity",
				"children": [
					{
						"open": {
							"description": {
								"identifier": "minecraft:player",
								"is_spawnable": false,
								"is_summonable": false,
								"is_experimental": false
							},
							"component_groups": {
								"minecraft:add_bad_omen": {
									"minecraft:spell_effects": {
										"add_effects": [
											{
												"effect": "bad_omen",
												"duration": 6000,
												"display_on_screen_animation": true
											}
										]
									},
									"minecraft:timer": {
										"time": [
											0,
											0
										],
										"looping": false,
										"time_down_event": {
											"event": "minecraft:clear_add_bad_omen",
											"target": "self"
										}
									}
								},
								"minecraft:clear_bad_omen_spell_effect": {
									"minecraft:spell_effects": {}
								},
								"minecraft:raid_trigger": {
									"minecraft:raid_trigger": {
										"triggered_event": {
											"event": "minecraft:remove_raid_trigger",
											"target": "self"
										}
									},
									"minecraft:spell_effects": {
										"remove_effects": "bad_omen"
									}
								},
								"gvs:comp": {
									"minecraft:timer": {
										"time": 20,
										"time_down_event": {
											"event": "gvs:final"
										}
									}
								},
								"gvs:give": {
									"minecraft:spawn_entity": [
										{
											"num_to_spawn": 1,
											"spawn_item": "minecraft:compound"
										}
									]
								}
							},
							"components": {
								"minecraft:experience_reward": {
									"on_death": "Math.Min(query.player_level * 7, 100)"
								},
								"minecraft:type_family": {
									"family": [
										"player"
									]
								},
								"minecraft:is_hidden_when_invisible": {},
								"minecraft:loot": {
									"table": "loot_tables/empty.json"
								},
								"minecraft:collision_box": {
									"width": 0.6,
									"height": 1.8
								},
								"minecraft:can_climb": {},
								"minecraft:movement": {
									"value": 0.1
								},
								"minecraft:hurt_on_condition": {
									"damage_conditions": [
										{
											"filters": {
												"test": "in_lava",
												"subject": "self",
												"operator": "==",
												"value": true
											},
											"cause": "lava",
											"damage_per_tick": 4
										}
									]
								},
								"minecraft:attack": {
									"damage": 1
								},
								"minecraft:player.saturation": {
									"value": 20
								},
								"minecraft:player.exhaustion": {
									"value": 0,
									"max": 4
								},
								"minecraft:player.level": {
									"value": 0,
									"max": 24791
								},
								"minecraft:player.experience": {
									"value": 0,
									"max": 1
								},
								"minecraft:breathable": {
									"total_supply": 15,
									"suffocate_time": -1,
									"inhale_time": 3.75,
									"generates_bubbles": false
								},
								"minecraft:nameable": {
									"always_show": true,
									"allow_name_tag_renaming": false
								},
								"minecraft:physics": {},
								"minecraft:pushable": {
									"is_pushable": false,
									"is_pushable_by_piston": true
								},
								"minecraft:insomnia": {
									"days_until_insomnia": 3
								},
								"minecraft:rideable": {
									"seat_count": 2,
									"family_types": [
										"parrot_tame"
									],
									"pull_in_entities": true,
									"seats": [
										{
											"position": [
												0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 0,
											"max_rider_count": 0,
											"lock_rider_rotation": 0
										},
										{
											"position": [
												-0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 1,
											"max_rider_count": 2,
											"lock_rider_rotation": 0
										}
									]
								},
								"minecraft:scaffolding_climber": {},
								"minecraft:environment_sensor": {
									"triggers": {
										"filters": {
											"all_of": [
												{
													"test": "has_mob_effect",
													"subject": "self",
													"value": "bad_omen"
												},
												{
													"test": "is_in_village",
													"subject": "self",
													"value": true
												}
											]
										},
										"event": "minecraft:trigger_raid"
									}
								},
								"minecraft:damage_sensor": {
									"triggers": [
										{
											"cause": "contact"
										},
										{
											"cause": "all",
											"on_damage": {
												"filters": {
													"with_damage_fatal": true
												},
												"event": "gvs:spawn_grave"
											}
										}
									]
								}
							},
							"events": {
								"minecraft:gain_bad_omen": {
									"add": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									}
								},
								"minecraft:clear_add_bad_omen": {
									"remove": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									},
									"add": {
										"component_groups": [
											"minecraft:clear_bad_omen_spell_effect"
										]
									}
								},
								"minecraft:trigger_raid": {
									"add": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"minecraft:remove_raid_trigger": {
									"remove": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"gvs:spawn_grave": {
									"execute": {
										"commands": [
											"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
											"/give @s mcbp:grave_key"
										]
									}
								},
								"gvs:final": {
									"add": {
										"component_groups": [
											"gvs:give"
										]
									}
								},
								"gvs:test": {}
							}
						},
						"key": "description",
						"is_minified": true,
						"children": {
							"identifier": "minecraft:player",
							"is_spawnable": false,
							"is_summonable": false,
							"is_experimental": false
						}
					},
					{
						"open": {
							"description": {
								"identifier": "minecraft:player",
								"is_spawnable": false,
								"is_summonable": false,
								"is_experimental": false
							},
							"component_groups": {
								"minecraft:add_bad_omen": {
									"minecraft:spell_effects": {
										"add_effects": [
											{
												"effect": "bad_omen",
												"duration": 6000,
												"display_on_screen_animation": true
											}
										]
									},
									"minecraft:timer": {
										"time": [
											0,
											0
										],
										"looping": false,
										"time_down_event": {
											"event": "minecraft:clear_add_bad_omen",
											"target": "self"
										}
									}
								},
								"minecraft:clear_bad_omen_spell_effect": {
									"minecraft:spell_effects": {}
								},
								"minecraft:raid_trigger": {
									"minecraft:raid_trigger": {
										"triggered_event": {
											"event": "minecraft:remove_raid_trigger",
											"target": "self"
										}
									},
									"minecraft:spell_effects": {
										"remove_effects": "bad_omen"
									}
								},
								"gvs:comp": {
									"minecraft:timer": {
										"time": 20,
										"time_down_event": {
											"event": "gvs:final"
										}
									}
								},
								"gvs:give": {
									"minecraft:spawn_entity": [
										{
											"num_to_spawn": 1,
											"spawn_item": "minecraft:compound"
										}
									]
								}
							},
							"components": {
								"minecraft:experience_reward": {
									"on_death": "Math.Min(query.player_level * 7, 100)"
								},
								"minecraft:type_family": {
									"family": [
										"player"
									]
								},
								"minecraft:is_hidden_when_invisible": {},
								"minecraft:loot": {
									"table": "loot_tables/empty.json"
								},
								"minecraft:collision_box": {
									"width": 0.6,
									"height": 1.8
								},
								"minecraft:can_climb": {},
								"minecraft:movement": {
									"value": 0.1
								},
								"minecraft:hurt_on_condition": {
									"damage_conditions": [
										{
											"filters": {
												"test": "in_lava",
												"subject": "self",
												"operator": "==",
												"value": true
											},
											"cause": "lava",
											"damage_per_tick": 4
										}
									]
								},
								"minecraft:attack": {
									"damage": 1
								},
								"minecraft:player.saturation": {
									"value": 20
								},
								"minecraft:player.exhaustion": {
									"value": 0,
									"max": 4
								},
								"minecraft:player.level": {
									"value": 0,
									"max": 24791
								},
								"minecraft:player.experience": {
									"value": 0,
									"max": 1
								},
								"minecraft:breathable": {
									"total_supply": 15,
									"suffocate_time": -1,
									"inhale_time": 3.75,
									"generates_bubbles": false
								},
								"minecraft:nameable": {
									"always_show": true,
									"allow_name_tag_renaming": false
								},
								"minecraft:physics": {},
								"minecraft:pushable": {
									"is_pushable": false,
									"is_pushable_by_piston": true
								},
								"minecraft:insomnia": {
									"days_until_insomnia": 3
								},
								"minecraft:rideable": {
									"seat_count": 2,
									"family_types": [
										"parrot_tame"
									],
									"pull_in_entities": true,
									"seats": [
										{
											"position": [
												0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 0,
											"max_rider_count": 0,
											"lock_rider_rotation": 0
										},
										{
											"position": [
												-0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 1,
											"max_rider_count": 2,
											"lock_rider_rotation": 0
										}
									]
								},
								"minecraft:scaffolding_climber": {},
								"minecraft:environment_sensor": {
									"triggers": {
										"filters": {
											"all_of": [
												{
													"test": "has_mob_effect",
													"subject": "self",
													"value": "bad_omen"
												},
												{
													"test": "is_in_village",
													"subject": "self",
													"value": true
												}
											]
										},
										"event": "minecraft:trigger_raid"
									}
								},
								"minecraft:damage_sensor": {
									"triggers": [
										{
											"cause": "contact"
										},
										{
											"cause": "all",
											"on_damage": {
												"filters": {
													"with_damage_fatal": true
												},
												"event": "gvs:spawn_grave"
											}
										}
									]
								}
							},
							"events": {
								"minecraft:gain_bad_omen": {
									"add": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									}
								},
								"minecraft:clear_add_bad_omen": {
									"remove": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									},
									"add": {
										"component_groups": [
											"minecraft:clear_bad_omen_spell_effect"
										]
									}
								},
								"minecraft:trigger_raid": {
									"add": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"minecraft:remove_raid_trigger": {
									"remove": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"gvs:spawn_grave": {
									"execute": {
										"commands": [
											"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
											"/give @s mcbp:grave_key"
										]
									}
								},
								"gvs:final": {
									"add": {
										"component_groups": [
											"gvs:give"
										]
									}
								},
								"gvs:test": {}
							}
						},
						"key": "component_groups",
						"children": [
							{
								"key": "minecraft:add_bad_omen",
								"is_minified": true,
								"children": {
									"minecraft:spell_effects": {
										"add_effects": [
											{
												"effect": "bad_omen",
												"duration": 6000,
												"display_on_screen_animation": true
											}
										]
									},
									"minecraft:timer": {
										"time": [
											0,
											0
										],
										"looping": false,
										"time_down_event": {
											"event": "minecraft:clear_add_bad_omen",
											"target": "self"
										}
									}
								}
							},
							{
								"key": "minecraft:clear_bad_omen_spell_effect",
								"is_minified": true,
								"children": {
									"minecraft:spell_effects": {}
								}
							},
							{
								"key": "minecraft:raid_trigger",
								"is_minified": true,
								"children": {
									"minecraft:raid_trigger": {
										"triggered_event": {
											"event": "minecraft:remove_raid_trigger",
											"target": "self"
										}
									},
									"minecraft:spell_effects": {
										"remove_effects": "bad_omen"
									}
								}
							},
							{
								"open": {
									"minecraft:add_bad_omen": {
										"minecraft:spell_effects": {
											"add_effects": [
												{
													"effect": "bad_omen",
													"duration": 6000,
													"display_on_screen_animation": true
												}
											]
										},
										"minecraft:timer": {
											"time": [
												0,
												0
											],
											"looping": false,
											"time_down_event": {
												"event": "minecraft:clear_add_bad_omen",
												"target": "self"
											}
										}
									},
									"minecraft:clear_bad_omen_spell_effect": {
										"minecraft:spell_effects": {}
									},
									"minecraft:raid_trigger": {
										"minecraft:raid_trigger": {
											"triggered_event": {
												"event": "minecraft:remove_raid_trigger",
												"target": "self"
											}
										},
										"minecraft:spell_effects": {
											"remove_effects": "bad_omen"
										}
									},
									"gvs:comp": {
										"minecraft:timer": {
											"time": 20,
											"time_down_event": {
												"event": "gvs:final"
											}
										}
									},
									"gvs:give": {
										"minecraft:spawn_entity": [
											{
												"num_to_spawn": 1,
												"spawn_item": "minecraft:compound"
											}
										]
									}
								},
								"key": "gvs:comp",
								"children": [
									{
										"open": {
											"minecraft:timer": {
												"time": 20,
												"time_down_event": {
													"event": "gvs:final"
												}
											}
										},
										"key": "minecraft:timer",
										"children": [
											{
												"data": "20",
												"key": "time"
											},
											{
												"open": {
													"time": 20,
													"time_down_event": {
														"event": "gvs:final"
													}
												},
												"key": "time_down_event",
												"is_minified": true,
												"children": {
													"event": "gvs:final"
												}
											}
										]
									}
								]
							},
							{
								"open": {
									"minecraft:add_bad_omen": {
										"minecraft:spell_effects": {
											"add_effects": [
												{
													"effect": "bad_omen",
													"duration": 6000,
													"display_on_screen_animation": true
												}
											]
										},
										"minecraft:timer": {
											"time": [
												0,
												0
											],
											"looping": false,
											"time_down_event": {
												"event": "minecraft:clear_add_bad_omen",
												"target": "self"
											}
										}
									},
									"minecraft:clear_bad_omen_spell_effect": {
										"minecraft:spell_effects": {}
									},
									"minecraft:raid_trigger": {
										"minecraft:raid_trigger": {
											"triggered_event": {
												"event": "minecraft:remove_raid_trigger",
												"target": "self"
											}
										},
										"minecraft:spell_effects": {
											"remove_effects": "bad_omen"
										}
									},
									"gvs:comp": {
										"minecraft:timer": {
											"time": 20,
											"time_down_event": {
												"event": "gvs:final"
											}
										}
									},
									"gvs:give": {
										"minecraft:spawn_entity": [
											{
												"num_to_spawn": 1,
												"spawn_item": "minecraft:compound"
											}
										]
									}
								},
								"key": "gvs:give",
								"children": [
									{
										"open": {
											"minecraft:spawn_entity": [
												{
													"num_to_spawn": 1,
													"spawn_item": "minecraft:compound"
												}
											]
										},
										"key": "minecraft:spawn_entity",
										"array": [
											{
												"open": [
													{
														"num_to_spawn": 1,
														"spawn_item": "minecraft:compound"
													}
												],
												"is_minified": true,
												"children": {
													"num_to_spawn": 1,
													"spawn_item": "minecraft:compound"
												}
											}
										]
									}
								]
							}
						]
					},
					{
						"open": {
							"description": {
								"identifier": "minecraft:player",
								"is_spawnable": false,
								"is_summonable": false,
								"is_experimental": false
							},
							"component_groups": {
								"minecraft:add_bad_omen": {
									"minecraft:spell_effects": {
										"add_effects": [
											{
												"effect": "bad_omen",
												"duration": 6000,
												"display_on_screen_animation": true
											}
										]
									},
									"minecraft:timer": {
										"time": [
											0,
											0
										],
										"looping": false,
										"time_down_event": {
											"event": "minecraft:clear_add_bad_omen",
											"target": "self"
										}
									}
								},
								"minecraft:clear_bad_omen_spell_effect": {
									"minecraft:spell_effects": {}
								},
								"minecraft:raid_trigger": {
									"minecraft:raid_trigger": {
										"triggered_event": {
											"event": "minecraft:remove_raid_trigger",
											"target": "self"
										}
									},
									"minecraft:spell_effects": {
										"remove_effects": "bad_omen"
									}
								},
								"gvs:comp": {
									"minecraft:timer": {
										"time": 20,
										"time_down_event": {
											"event": "gvs:final"
										}
									}
								},
								"gvs:give": {
									"minecraft:spawn_entity": [
										{
											"num_to_spawn": 1,
											"spawn_item": "minecraft:compound"
										}
									]
								}
							},
							"components": {
								"minecraft:experience_reward": {
									"on_death": "Math.Min(query.player_level * 7, 100)"
								},
								"minecraft:type_family": {
									"family": [
										"player"
									]
								},
								"minecraft:is_hidden_when_invisible": {},
								"minecraft:loot": {
									"table": "loot_tables/empty.json"
								},
								"minecraft:collision_box": {
									"width": 0.6,
									"height": 1.8
								},
								"minecraft:can_climb": {},
								"minecraft:movement": {
									"value": 0.1
								},
								"minecraft:hurt_on_condition": {
									"damage_conditions": [
										{
											"filters": {
												"test": "in_lava",
												"subject": "self",
												"operator": "==",
												"value": true
											},
											"cause": "lava",
											"damage_per_tick": 4
										}
									]
								},
								"minecraft:attack": {
									"damage": 1
								},
								"minecraft:player.saturation": {
									"value": 20
								},
								"minecraft:player.exhaustion": {
									"value": 0,
									"max": 4
								},
								"minecraft:player.level": {
									"value": 0,
									"max": 24791
								},
								"minecraft:player.experience": {
									"value": 0,
									"max": 1
								},
								"minecraft:breathable": {
									"total_supply": 15,
									"suffocate_time": -1,
									"inhale_time": 3.75,
									"generates_bubbles": false
								},
								"minecraft:nameable": {
									"always_show": true,
									"allow_name_tag_renaming": false
								},
								"minecraft:physics": {},
								"minecraft:pushable": {
									"is_pushable": false,
									"is_pushable_by_piston": true
								},
								"minecraft:insomnia": {
									"days_until_insomnia": 3
								},
								"minecraft:rideable": {
									"seat_count": 2,
									"family_types": [
										"parrot_tame"
									],
									"pull_in_entities": true,
									"seats": [
										{
											"position": [
												0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 0,
											"max_rider_count": 0,
											"lock_rider_rotation": 0
										},
										{
											"position": [
												-0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 1,
											"max_rider_count": 2,
											"lock_rider_rotation": 0
										}
									]
								},
								"minecraft:scaffolding_climber": {},
								"minecraft:environment_sensor": {
									"triggers": {
										"filters": {
											"all_of": [
												{
													"test": "has_mob_effect",
													"subject": "self",
													"value": "bad_omen"
												},
												{
													"test": "is_in_village",
													"subject": "self",
													"value": true
												}
											]
										},
										"event": "minecraft:trigger_raid"
									}
								},
								"minecraft:damage_sensor": {
									"triggers": [
										{
											"cause": "contact"
										},
										{
											"cause": "all",
											"on_damage": {
												"filters": {
													"with_damage_fatal": true
												},
												"event": "gvs:spawn_grave"
											}
										}
									]
								}
							},
							"events": {
								"minecraft:gain_bad_omen": {
									"add": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									}
								},
								"minecraft:clear_add_bad_omen": {
									"remove": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									},
									"add": {
										"component_groups": [
											"minecraft:clear_bad_omen_spell_effect"
										]
									}
								},
								"minecraft:trigger_raid": {
									"add": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"minecraft:remove_raid_trigger": {
									"remove": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"gvs:spawn_grave": {
									"execute": {
										"commands": [
											"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
											"/give @s mcbp:grave_key"
										]
									}
								},
								"gvs:final": {
									"add": {
										"component_groups": [
											"gvs:give"
										]
									}
								},
								"gvs:test": {}
							}
						},
						"key": "components",
						"children": [
							{
								"key": "minecraft:experience_reward",
								"is_minified": true,
								"children": {
									"on_death": "Math.Min(query.player_level * 7, 100)"
								}
							},
							{
								"key": "minecraft:type_family",
								"is_minified": true,
								"children": {
									"family": [
										"player"
									]
								}
							},
							{
								"key": "minecraft:is_hidden_when_invisible",
								"is_minified": true,
								"children": {}
							},
							{
								"key": "minecraft:loot",
								"is_minified": true,
								"children": {
									"table": "loot_tables/empty.json"
								}
							},
							{
								"key": "minecraft:collision_box",
								"is_minified": true,
								"children": {
									"width": 0.6,
									"height": 1.8
								}
							},
							{
								"key": "minecraft:can_climb",
								"is_minified": true,
								"children": {}
							},
							{
								"key": "minecraft:movement",
								"is_minified": true,
								"children": {
									"value": 0.1
								}
							},
							{
								"key": "minecraft:hurt_on_condition",
								"is_minified": true,
								"children": {
									"damage_conditions": [
										{
											"filters": {
												"test": "in_lava",
												"subject": "self",
												"operator": "==",
												"value": true
											},
											"cause": "lava",
											"damage_per_tick": 4
										}
									]
								}
							},
							{
								"key": "minecraft:attack",
								"is_minified": true,
								"children": {
									"damage": 1
								}
							},
							{
								"key": "minecraft:player.saturation",
								"is_minified": true,
								"children": {
									"value": 20
								}
							},
							{
								"key": "minecraft:player.exhaustion",
								"is_minified": true,
								"children": {
									"value": 0,
									"max": 4
								}
							},
							{
								"key": "minecraft:player.level",
								"is_minified": true,
								"children": {
									"value": 0,
									"max": 24791
								}
							},
							{
								"key": "minecraft:player.experience",
								"is_minified": true,
								"children": {
									"value": 0,
									"max": 1
								}
							},
							{
								"key": "minecraft:breathable",
								"is_minified": true,
								"children": {
									"total_supply": 15,
									"suffocate_time": -1,
									"inhale_time": 3.75,
									"generates_bubbles": false
								}
							},
							{
								"key": "minecraft:nameable",
								"is_minified": true,
								"children": {
									"always_show": true,
									"allow_name_tag_renaming": false
								}
							},
							{
								"key": "minecraft:physics",
								"is_minified": true,
								"children": {}
							},
							{
								"key": "minecraft:pushable",
								"is_minified": true,
								"children": {
									"is_pushable": false,
									"is_pushable_by_piston": true
								}
							},
							{
								"key": "minecraft:insomnia",
								"is_minified": true,
								"children": {
									"days_until_insomnia": 3
								}
							},
							{
								"key": "minecraft:rideable",
								"is_minified": true,
								"children": {
									"seat_count": 2,
									"family_types": [
										"parrot_tame"
									],
									"pull_in_entities": true,
									"seats": [
										{
											"position": [
												0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 0,
											"max_rider_count": 0,
											"lock_rider_rotation": 0
										},
										{
											"position": [
												-0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 1,
											"max_rider_count": 2,
											"lock_rider_rotation": 0
										}
									]
								}
							},
							{
								"key": "minecraft:scaffolding_climber",
								"is_minified": true,
								"children": {}
							},
							{
								"key": "minecraft:environment_sensor",
								"is_minified": true,
								"children": {
									"triggers": {
										"filters": {
											"all_of": [
												{
													"test": "has_mob_effect",
													"subject": "self",
													"value": "bad_omen"
												},
												{
													"test": "is_in_village",
													"subject": "self",
													"value": true
												}
											]
										},
										"event": "minecraft:trigger_raid"
									}
								}
							},
							{
								"open": {
									"minecraft:experience_reward": {
										"on_death": "Math.Min(query.player_level * 7, 100)"
									},
									"minecraft:type_family": {
										"family": [
											"player"
										]
									},
									"minecraft:is_hidden_when_invisible": {},
									"minecraft:loot": {
										"table": "loot_tables/empty.json"
									},
									"minecraft:collision_box": {
										"width": 0.6,
										"height": 1.8
									},
									"minecraft:can_climb": {},
									"minecraft:movement": {
										"value": 0.1
									},
									"minecraft:hurt_on_condition": {
										"damage_conditions": [
											{
												"filters": {
													"test": "in_lava",
													"subject": "self",
													"operator": "==",
													"value": true
												},
												"cause": "lava",
												"damage_per_tick": 4
											}
										]
									},
									"minecraft:attack": {
										"damage": 1
									},
									"minecraft:player.saturation": {
										"value": 20
									},
									"minecraft:player.exhaustion": {
										"value": 0,
										"max": 4
									},
									"minecraft:player.level": {
										"value": 0,
										"max": 24791
									},
									"minecraft:player.experience": {
										"value": 0,
										"max": 1
									},
									"minecraft:breathable": {
										"total_supply": 15,
										"suffocate_time": -1,
										"inhale_time": 3.75,
										"generates_bubbles": false
									},
									"minecraft:nameable": {
										"always_show": true,
										"allow_name_tag_renaming": false
									},
									"minecraft:physics": {},
									"minecraft:pushable": {
										"is_pushable": false,
										"is_pushable_by_piston": true
									},
									"minecraft:insomnia": {
										"days_until_insomnia": 3
									},
									"minecraft:rideable": {
										"seat_count": 2,
										"family_types": [
											"parrot_tame"
										],
										"pull_in_entities": true,
										"seats": [
											{
												"position": [
													0.4,
													-0.2,
													-0.1
												],
												"min_rider_count": 0,
												"max_rider_count": 0,
												"lock_rider_rotation": 0
											},
											{
												"position": [
													-0.4,
													-0.2,
													-0.1
												],
												"min_rider_count": 1,
												"max_rider_count": 2,
												"lock_rider_rotation": 0
											}
										]
									},
									"minecraft:scaffolding_climber": {},
									"minecraft:environment_sensor": {
										"triggers": {
											"filters": {
												"all_of": [
													{
														"test": "has_mob_effect",
														"subject": "self",
														"value": "bad_omen"
													},
													{
														"test": "is_in_village",
														"subject": "self",
														"value": true
													}
												]
											},
											"event": "minecraft:trigger_raid"
										}
									},
									"minecraft:damage_sensor": {
										"triggers": [
											{
												"cause": "contact"
											},
											{
												"cause": "all",
												"on_damage": {
													"filters": {
														"with_damage_fatal": true
													},
													"event": "gvs:spawn_grave"
												}
											}
										]
									}
								},
								"key": "minecraft:damage_sensor",
								"children": [
									{
										"open": {
											"triggers": [
												{
													"cause": "contact"
												},
												{
													"cause": "all",
													"on_damage": {
														"filters": {
															"with_damage_fatal": true
														},
														"event": "gvs:spawn_grave"
													}
												}
											]
										},
										"key": "triggers",
										"array": [
											{
												"open": [
													{
														"cause": "contact"
													},
													{
														"cause": "all",
														"on_damage": {
															"filters": {
																"with_damage_fatal": true
															},
															"event": "gvs:spawn_grave"
														}
													}
												],
												"is_minified": true,
												"children": {
													"cause": "contact"
												}
											},
											{
												"open": [
													{
														"cause": "contact"
													},
													{
														"cause": "all",
														"on_damage": {
															"filters": {
																"with_damage_fatal": true
															},
															"event": "gvs:spawn_grave"
														}
													}
												],
												"children": [
													{
														"data": "all",
														"key": "cause"
													},
													{
														"open": {
															"cause": "all",
															"on_damage": {
																"filters": {
																	"with_damage_fatal": true
																},
																"event": "gvs:spawn_grave"
															}
														},
														"key": "on_damage",
														"is_minified": true,
														"children": {
															"filters": {
																"with_damage_fatal": true
															},
															"event": "gvs:spawn_grave"
														}
													}
												]
											}
										]
									}
								]
							}
						]
					},
					{
						"open": {
							"description": {
								"identifier": "minecraft:player",
								"is_spawnable": false,
								"is_summonable": false,
								"is_experimental": false
							},
							"component_groups": {
								"minecraft:add_bad_omen": {
									"minecraft:spell_effects": {
										"add_effects": [
											{
												"effect": "bad_omen",
												"duration": 6000,
												"display_on_screen_animation": true
											}
										]
									},
									"minecraft:timer": {
										"time": [
											0,
											0
										],
										"looping": false,
										"time_down_event": {
											"event": "minecraft:clear_add_bad_omen",
											"target": "self"
										}
									}
								},
								"minecraft:clear_bad_omen_spell_effect": {
									"minecraft:spell_effects": {}
								},
								"minecraft:raid_trigger": {
									"minecraft:raid_trigger": {
										"triggered_event": {
											"event": "minecraft:remove_raid_trigger",
											"target": "self"
										}
									},
									"minecraft:spell_effects": {
										"remove_effects": "bad_omen"
									}
								},
								"gvs:comp": {
									"minecraft:timer": {
										"time": 20,
										"time_down_event": {
											"event": "gvs:final"
										}
									}
								},
								"gvs:give": {
									"minecraft:spawn_entity": [
										{
											"num_to_spawn": 1,
											"spawn_item": "minecraft:compound"
										}
									]
								}
							},
							"components": {
								"minecraft:experience_reward": {
									"on_death": "Math.Min(query.player_level * 7, 100)"
								},
								"minecraft:type_family": {
									"family": [
										"player"
									]
								},
								"minecraft:is_hidden_when_invisible": {},
								"minecraft:loot": {
									"table": "loot_tables/empty.json"
								},
								"minecraft:collision_box": {
									"width": 0.6,
									"height": 1.8
								},
								"minecraft:can_climb": {},
								"minecraft:movement": {
									"value": 0.1
								},
								"minecraft:hurt_on_condition": {
									"damage_conditions": [
										{
											"filters": {
												"test": "in_lava",
												"subject": "self",
												"operator": "==",
												"value": true
											},
											"cause": "lava",
											"damage_per_tick": 4
										}
									]
								},
								"minecraft:attack": {
									"damage": 1
								},
								"minecraft:player.saturation": {
									"value": 20
								},
								"minecraft:player.exhaustion": {
									"value": 0,
									"max": 4
								},
								"minecraft:player.level": {
									"value": 0,
									"max": 24791
								},
								"minecraft:player.experience": {
									"value": 0,
									"max": 1
								},
								"minecraft:breathable": {
									"total_supply": 15,
									"suffocate_time": -1,
									"inhale_time": 3.75,
									"generates_bubbles": false
								},
								"minecraft:nameable": {
									"always_show": true,
									"allow_name_tag_renaming": false
								},
								"minecraft:physics": {},
								"minecraft:pushable": {
									"is_pushable": false,
									"is_pushable_by_piston": true
								},
								"minecraft:insomnia": {
									"days_until_insomnia": 3
								},
								"minecraft:rideable": {
									"seat_count": 2,
									"family_types": [
										"parrot_tame"
									],
									"pull_in_entities": true,
									"seats": [
										{
											"position": [
												0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 0,
											"max_rider_count": 0,
											"lock_rider_rotation": 0
										},
										{
											"position": [
												-0.4,
												-0.2,
												-0.1
											],
											"min_rider_count": 1,
											"max_rider_count": 2,
											"lock_rider_rotation": 0
										}
									]
								},
								"minecraft:scaffolding_climber": {},
								"minecraft:environment_sensor": {
									"triggers": {
										"filters": {
											"all_of": [
												{
													"test": "has_mob_effect",
													"subject": "self",
													"value": "bad_omen"
												},
												{
													"test": "is_in_village",
													"subject": "self",
													"value": true
												}
											]
										},
										"event": "minecraft:trigger_raid"
									}
								},
								"minecraft:damage_sensor": {
									"triggers": [
										{
											"cause": "contact"
										},
										{
											"cause": "all",
											"on_damage": {
												"filters": {
													"with_damage_fatal": true
												},
												"event": "gvs:spawn_grave"
											}
										}
									]
								}
							},
							"events": {
								"minecraft:gain_bad_omen": {
									"add": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									}
								},
								"minecraft:clear_add_bad_omen": {
									"remove": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									},
									"add": {
										"component_groups": [
											"minecraft:clear_bad_omen_spell_effect"
										]
									}
								},
								"minecraft:trigger_raid": {
									"add": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"minecraft:remove_raid_trigger": {
									"remove": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								},
								"gvs:spawn_grave": {
									"execute": {
										"commands": [
											"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
											"/give @s mcbp:grave_key"
										]
									}
								},
								"gvs:final": {
									"add": {
										"component_groups": [
											"gvs:give"
										]
									}
								},
								"gvs:test": {}
							}
						},
						"key": "events",
						"children": [
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "minecraft:gain_bad_omen",
								"is_minified": true,
								"children": {
									"add": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									}
								}
							},
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "minecraft:clear_add_bad_omen",
								"is_minified": true,
								"children": {
									"remove": {
										"component_groups": [
											"minecraft:add_bad_omen"
										]
									},
									"add": {
										"component_groups": [
											"minecraft:clear_bad_omen_spell_effect"
										]
									}
								}
							},
							{
								"key": "minecraft:trigger_raid",
								"is_minified": true,
								"children": {
									"add": {
										"component_groups": [
											"minecraft:raid_trigger"
										]
									}
								}
							},
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "minecraft:remove_raid_trigger",
								"children": [
									{
										"open": {
											"remove": {
												"component_groups": [
													"minecraft:raid_trigger"
												]
											}
										},
										"key": "remove",
										"is_minified": true,
										"children": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									}
								]
							},
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "gvs:spawn_grave",
								"children": [
									{
										"open": {
											"execute": {
												"commands": [
													"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
													"/give @s mcbp:grave_key"
												]
											}
										},
										"key": "execute",
										"children": [
											{
												"open": {
													"commands": [
														"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
														"/give @s mcbp:grave_key"
													]
												},
												"key": "commands",
												"is_minified": true,
												"array": [
													"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
													"/give @s mcbp:grave_key"
												]
											}
										]
									}
								]
							},
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "gvs:final",
								"children": [
									{
										"open": {
											"add": {
												"component_groups": [
													"gvs:give"
												]
											}
										},
										"key": "add",
										"children": [
											{
												"open": {
													"component_groups": [
														"gvs:give"
													]
												},
												"key": "component_groups",
												"is_minified": true,
												"array": [
													"gvs:give"
												]
											}
										]
									}
								]
							},
							{
								"open": {
									"minecraft:gain_bad_omen": {
										"add": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										}
									},
									"minecraft:clear_add_bad_omen": {
										"remove": {
											"component_groups": [
												"minecraft:add_bad_omen"
											]
										},
										"add": {
											"component_groups": [
												"minecraft:clear_bad_omen_spell_effect"
											]
										}
									},
									"minecraft:trigger_raid": {
										"add": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"minecraft:remove_raid_trigger": {
										"remove": {
											"component_groups": [
												"minecraft:raid_trigger"
											]
										}
									},
									"gvs:spawn_grave": {
										"execute": {
											"commands": [
												"/summon mcbp:thomb ~ ~ ~ a §c¤GraveStone¤",
												"/give @s mcbp:grave_key"
											]
										}
									},
									"gvs:final": {
										"add": {
											"component_groups": [
												"gvs:give"
											]
										}
									},
									"gvs:test": {}
								},
								"key": "gvs:test",
								"is_minified": true,
								"children": {}
							}
						]
					}
				]
			}
		]
	}
}